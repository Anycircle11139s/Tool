const map = { m: 1, km: 1000, mi: 1609.34, ft: 0.3048 };
document.getElementById('convert-btn').addEventListener('click', () => {
  const v = parseFloat(document.getElementById('num').value);
  if (isNaN(v)) return;
  const from = document.getElementById('from').value;
  const to = document.getElementById('to').value;
  const res = (v * map[from]) / map[to];
  document.getElementById('conv-result').textContent = `${v} ${from} = ${res.toFixed(4)} ${to}`;
});
