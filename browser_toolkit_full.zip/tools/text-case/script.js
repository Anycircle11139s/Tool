function convert(mode) {
  const txt = document.getElementById('text-inp').value;
  let res = txt;
  if (mode === 'upper') res = txt.toUpperCase();
  else if (mode === 'lower') res = txt.toLowerCase();
  else if (mode === 'title')
    res = txt.replace(/\w\S*/g, w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
  else if (mode === 'sentence')
    res = txt.charAt(0).toUpperCase() + txt.slice(1).toLowerCase();
  document.getElementById('out').value = res;
}
document.querySelectorAll('[data-mode]').forEach(b => (b.onclick = () => convert(b.dataset.mode)));
